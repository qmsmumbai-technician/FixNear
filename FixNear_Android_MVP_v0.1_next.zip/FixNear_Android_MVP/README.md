# FixNear Android MVP v0.1

Starter Android project based on the supplied FixNear prototype specification.

Included in this starter:
- Customer home and service selection
- Nearby technician demo list
- Technician mode with online/offline switch
- Demo service request
- Location permission request

Next implementation phase:
- Real GPS distance calculation
- Cloud database
- OTP authentication
- Real-time push notifications
- Technician verification
- Payments
- Admin authentication/panel

This project is a starter implementation and is not yet the final production APK.
